"""
Sandworm geometry.

Local frame of every display entity (all sit at the pivot on the sand surface):
    +Z = forward (toward the player), +Y = up, +X = sideways.
Entity yaw rotates this whole frame, so turning the worm = one rotation.

A "pose" is a list of block_display transformations (one per part).
"""
import math
import numpy as np
from scipy.optimize import least_squares

# ------------------------------------------------------------------ config
WORM_LENGTH = 16.0
BODY_BLOCK = "minecraft:mud"
THROAT_BLOCK = "minecraft:blackstone"
TOOTH_BLOCK = "minecraft:bone_block"

N_SEG = 9                      # body segments (each = 2 crossed cubes -> octagonal "star" tube)
SEG_S0, SEG_DS = 0.8, 1.45     # arclength of first segment centre / spacing
SEG_LEN = 2.6                  # cube length (overlaps neighbours -> no gaps on bends)
SEG_W_THICK, SEG_W_THIN = 3.5, 3.1   # alternating widths -> Dune-style ridged rings
TAPER = {0: 2.4, 1: 2.8}       # tail is narrower (buried anyway)
HEAD_S, HEAD_W, HEAD_LEN = 13.9, 4.0, 2.6
THROAT_W, THROAT_LEN = 2.8, 0.5
N_TEETH, TOOTH_RING_R = 8, 1.85
TOOTH_SIZE = (0.55, 0.55, 1.5)
TOOTH_TILT = math.radians(14)

# idle "hook" path (arch radius / centre height / horizontal origin)
ARCH_R = 4.2
ARCH_YC = 4.05
PATH_Z0 = -2.5
PATH_UV = 60.0                 # length of the (underground) vertical run before the arch
IDLE_HEAD_TURN = 135.0         # degrees of arch already travelled by the head in idle

# ------------------------------------------------------------------ parts
PARTS = []      # (block, kind, extra)
for k in range(N_SEG):
    PARTS.append((BODY_BLOCK, "segA", k))
    PARTS.append((BODY_BLOCK, "segB", k))
PARTS.append((BODY_BLOCK, "headA", 0))
PARTS.append((BODY_BLOCK, "headB", 0))
PARTS.append((THROAT_BLOCK, "throat", 0))
for t in range(N_TEETH):
    PARTS.append((TOOTH_BLOCK, "tooth", t))
N_PARTS = len(PARTS)


# ------------------------------------------------------------------ spines
class PathSpine:
    """Arch path; spine(s) = path(u_tail + s)."""
    def __init__(self, u_tail):
        self.u_tail = u_tail

    @staticmethod
    def path(u):
        R, yc, z0, uv = ARCH_R, ARCH_YC, PATH_Z0, PATH_UV
        if u <= uv:
            return z0, yc - (uv - u), math.pi / 2
        a = (u - uv) / R
        if a <= math.pi:
            return z0 + R - R * math.cos(a), yc + R * math.sin(a), math.pi / 2 - a
        d = u - uv - math.pi * R
        return z0 + 2 * R, yc - d, -math.pi / 2

    def __call__(self, s):
        return self.path(self.u_tail + s)


def idle_u_tail():
    return PATH_UV + ARCH_R * math.radians(IDLE_HEAD_TURN) - WORM_LENGTH


class KnotSpine:
    """Heading-profile spine integrated numerically from a start point."""
    def __init__(self, start, knots, ds=0.01):
        # knots: [(s, heading_deg), ...] piecewise linear
        ss = np.arange(0, WORM_LENGTH + 3 + ds, ds)
        ks, kh = zip(*knots)
        ph = np.radians(np.interp(ss, ks, kh))
        z = start[0] + np.concatenate([[0], np.cumsum(np.cos(ph[:-1]) * ds)])
        y = start[1] + np.concatenate([[0], np.cumsum(np.sin(ph[:-1]) * ds)])
        self.ss, self.z, self.y, self.ph = ss, z, y, ph

    def __call__(self, s):
        return (float(np.interp(s, self.ss, self.z)),
                float(np.interp(s, self.ss, self.y)),
                float(np.interp(s, self.ss, self.ph)))


class ShiftedSpine:
    def __init__(self, base, dz=0.0, dy=0.0):
        self.base, self.dz, self.dy = base, dz, dy

    def __call__(self, s):
        z, y, p = self.base(s)
        return z + self.dz, y + self.dy, p


IDLE = PathSpine(idle_u_tail())
START = IDLE(0.0)[:2]           # tail start point (z, y) in idle


# ------------------------------------------------------------------ math
def mat_basis(phi):
    """Orientation of a cube whose local Z follows the tangent heading phi
    (elevation, radians) inside the forward/up plane; local X stays horizontal."""
    s, c = math.sin(phi), math.cos(phi)
    x = np.array([1.0, 0.0, 0.0])
    y = np.array([0.0, c, -s])
    z = np.array([0.0, s, c])
    return np.stack([x, y, z], axis=1)          # columns = local axes


def rot_z(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1.0]])


def mat_to_quat(m):
    t = np.trace(m)
    if t > 0:
        s = math.sqrt(t + 1.0) * 2
        w = 0.25 * s
        x = (m[2, 1] - m[1, 2]) / s
        y = (m[0, 2] - m[2, 0]) / s
        z = (m[1, 0] - m[0, 1]) / s
    elif m[0, 0] > m[1, 1] and m[0, 0] > m[2, 2]:
        s = math.sqrt(1.0 + m[0, 0] - m[1, 1] - m[2, 2]) * 2
        w = (m[2, 1] - m[1, 2]) / s
        x = 0.25 * s
        y = (m[0, 1] + m[1, 0]) / s
        z = (m[0, 2] + m[2, 0]) / s
    elif m[1, 1] > m[2, 2]:
        s = math.sqrt(1.0 + m[1, 1] - m[0, 0] - m[2, 2]) * 2
        w = (m[0, 2] - m[2, 0]) / s
        x = (m[0, 1] + m[1, 0]) / s
        y = 0.25 * s
        z = (m[1, 2] + m[2, 1]) / s
    else:
        s = math.sqrt(1.0 + m[2, 2] - m[0, 0] - m[1, 1]) * 2
        w = (m[1, 0] - m[0, 1]) / s
        x = (m[0, 2] + m[2, 0]) / s
        y = (m[1, 2] + m[2, 1]) / s
        z = 0.25 * s
    q = np.array([x, y, z, w])
    return q / np.linalg.norm(q)


def make_part(center, R, size):
    """Transformation for a unit block so that it becomes an oriented box of
    `size` centred on `center` (entity-local coords) with orientation R."""
    size = np.asarray(size, float)
    T = np.asarray(center, float) - R @ (size / 2.0)
    return {"T": T, "R": R, "S": size, "C": np.asarray(center, float)}


# ------------------------------------------------------------------ pose
def build_pose(spine):
    """Return list of part dicts (one per PARTS entry) plus info dict."""
    out = []
    head_center = None
    head_R = None
    for block, kind, extra in PARTS:
        if kind in ("segA", "segB"):
            k = extra
            s = SEG_S0 + SEG_DS * k
            z, y, ph = spine(s)
            a = TAPER.get(k, SEG_W_THICK if k % 2 == 0 else SEG_W_THIN)
            R = mat_basis(ph)
            if kind == "segB":
                R = R @ rot_z(math.radians(45))
                out.append(make_part((0, y, z), R, (a, a, SEG_LEN + 0.06)))
            else:
                out.append(make_part((0, y, z), R, (a, a, SEG_LEN)))
        elif kind in ("headA", "headB"):
            z, y, ph = spine(HEAD_S)
            head_center = np.array([0, y, z])
            head_R = mat_basis(ph)
            R = head_R if kind == "headA" else head_R @ rot_z(math.radians(45))
            out.append(make_part(head_center, R,
                                 (HEAD_W, HEAD_W, HEAD_LEN + (0.06 if kind == "headB" else 0))))
        elif kind == "throat":
            c = head_center + head_R @ np.array([0, 0, HEAD_LEN / 2 + THROAT_LEN / 2 - 0.2])
            # Turn the block so its TOP (+Y) face points out of the mouth (head forward),
            # so the throat shows the block's top texture. Block-local axes in head coords:
            #   x -> (1,0,0), y -> forward (0,0,1), z -> (0,-1,0). Thickness is now block-local Y.
            R_top = head_R @ np.array([[1.0, 0.0, 0.0],
                                       [0.0, 0.0, -1.0],
                                       [0.0, 1.0, 0.0]])
            out.append(make_part(c, R_top, (THROAT_W, THROAT_LEN, THROAT_W)))
        else:  # tooth
            ang = 2 * math.pi * extra / N_TEETH + math.pi / 8
            radial = np.array([math.cos(ang), math.sin(ang), 0.0])
            tang = np.array([-math.sin(ang), math.cos(ang), 0.0])
            zt = np.array([0, 0, 1.0]) * math.cos(TOOTH_TILT) - radial * math.sin(TOOTH_TILT)
            xt = tang
            yt = np.cross(zt, xt)
            Rl = np.stack([xt, yt, zt], axis=1)
            Rw = head_R @ Rl
            local_c = radial * TOOTH_RING_R + np.array([0, 0, HEAD_LEN / 2 + 0.35])
            c = head_center + head_R @ local_c
            out.append(make_part(c, Rw, TOOTH_SIZE))
    zh, yh, ph = spine(HEAD_S)
    fwd = np.array([0, math.sin(ph), math.cos(ph)])
    tip = np.array([0, yh, zh]) + fwd * (HEAD_LEN / 2 + THROAT_LEN - 0.2 + 0.3)
    info = {"tip_z": float(tip[2]), "tip_y": float(tip[1]),
            "head_z": float(zh), "head_y": float(yh), "head_phi": math.degrees(ph)}
    return out, info


def part_top(p):
    ext = np.abs(p["R"][1, :]) * p["S"] / 2.0
    return p["C"][1] + ext.sum()


def pose_top(parts):
    return max(part_top(p) for p in parts)


def shifted(parts, dz=0.0, dy=0.0):
    out = []
    for p in parts:
        d = np.array([0, dy, dz])
        out.append({"T": p["T"] + d, "R": p["R"], "S": p["S"], "C": p["C"] + d})
    return out


# ------------------------------------------------------------------ solvers
def solve_knot_pose(target_tip, phi_end_hint=-60.0, dz0=0.0, seed_grid=True,
                    max_curv=17.0):
    """Find (s1, kappa) so a 'vertical then constant-curvature' spine puts the
    mouth tip at target_tip=(z, y). Curvature limited so the body doesn't kink."""
    start = (START[0] + dz0, START[1])

    def make(s1, kap):
        return KnotSpine(start, [(0, 90), (s1, 90), (WORM_LENGTH + 3, 90 - kap * (WORM_LENGTH + 3 - s1))])

    def resid(v):
        sp = make(*v)
        _, info = build_pose(sp)
        return [info["tip_z"] - target_tip[0], info["tip_y"] - target_tip[1]]

    best = None
    for s1 in np.linspace(0.5, 14, 10):
        for kap in np.linspace(3, max_curv, 8):
            try:
                r = least_squares(resid, [s1, kap], bounds=([0.0, 2.0], [15.5, max_curv]))
            except Exception:
                continue
            err = math.hypot(*r.fun)
            cost = err + 0.02 * r.x[1]
            if best is None or cost < best[0]:
                best = (cost, err, r.x)
    _, err, (s1, kap) = best
    return make(s1, kap), err, (s1, kap)


# ------------------------------------------------------------------ format
def f(v):
    v = 0.0 if abs(v) < 5e-5 else v
    return f"{v:.4f}f"


def quat_for(p, ref_q=None):
    q = mat_to_quat(p["R"])
    if ref_q is not None and np.dot(q, ref_q) < 0:
        q = -q
    return q


def transformation_nbt(p, ref_q=None):
    q = quat_for(p, ref_q)
    T, S = p["T"], p["S"]
    # entity-local coords are (x, y, z) but we stored centres as (0, y, z) arrays => index 0=x,1=y,2=z
    return ("transformation:{translation:[%s,%s,%s],left_rotation:[%s,%s,%s,%s],"
            "scale:[%s,%s,%s],right_rotation:[0f,0f,0f,1f]}" % (
                f(T[0]), f(T[1]), f(T[2]), f(q[0]), f(q[1]), f(q[2]), f(q[3]),
                f(S[0]), f(S[1]), f(S[2])))


def _solve_smash_search(R, target_y=-0.4):
    """Pick the tail shift (dz0) + bend that put the mouth tip at (R, target_y).
    Prefers the smallest |shift| whose bend is gentle."""
    best = None
    for dz0 in sorted(np.arange(-3.0, 6.01, 0.5), key=abs):
        for maxc in (14.0, 20.0, 26.0):
            sp, err, prm = solve_knot_pose((R, target_y), dz0=float(dz0), max_curv=maxc)
            if err < 0.08 and prm[0] > 0.8:
                return sp, float(dz0), prm, err
            if best is None or err < best[3]:
                best = (sp, float(dz0), prm, err)
    return best


def slide_spine(head_y=0.5, phi_h=6.0, kappa=15.0, dy=-2.1):
    """Buried tail, one bend up to near-horizontal, then a flat body half-sunk in the sand."""
    d = (90 - phi_h) / kappa
    start = (START[0], START[1] + dy)

    def make(s1):
        return KnotSpine(start, [(0, 90), (s1, 90), (s1 + d, phi_h), (WORM_LENGTH + 3, phi_h)])

    def resid(v):
        return [build_pose(make(v[0]))[1]["head_y"] - head_y]
    r = least_squares(resid, [3.0], bounds=([0.0], [12.0]))
    return make(r.x[0]), float(r.x[0])


# Solutions from the full search (dz0, s1, kappa). Used as starting points so a rebuild takes seconds;
# if a hint no longer hits the target (e.g. you changed the worm's size) the full search runs instead.
SMASH_HINTS = {5: (0.0, 3.01, 15.8), 7: (0.0, 1.50, 12.6), 9: (1.5, 1.06, 11.8),
               11: (3.5, 1.06, 11.8), 13: (5.5, 1.06, 11.8)}


def solve_smash(R, target_y=-0.4):
    if R in SMASH_HINTS:
        dz0, s1, kap = SMASH_HINTS[R]
        start = (START[0] + dz0, START[1])

        def make(a, b):
            return KnotSpine(start, [(0, 90), (a, 90), (WORM_LENGTH + 3, 90 - b * (WORM_LENGTH + 3 - a))])

        def resid(v):
            info = build_pose(make(*v))[1]
            return [info["tip_z"] - R, info["tip_y"] - target_y]
        r = least_squares(resid, [s1, kap], bounds=([0.0, 2.0], [15.5, 26.0]))
        err = math.hypot(*r.fun)
        if err < 0.08:
            return make(*r.x), float(dz0), r.x, err
    return _solve_smash_search(R, target_y)
