import math, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from worm_geom import *

def draw(ax, parts, title, color_by=True):
    ax.axhline(0, color="#c9a46a", lw=6, zorder=0)
    for (blk, kind, ex), p in zip(PARTS, parts):
        # side-view silhouette of the oriented box: project 8 corners to (z,y), convex hull
        corners = []
        for sx in (0,1):
            for sy in (0,1):
                for sz in (0,1):
                    v = p["T"] + p["R"] @ (p["S"]*np.array([sx,sy,sz]))
                    corners.append((v[2], v[1]))
        pts = np.array(corners)
        from scipy.spatial import ConvexHull
        h = ConvexHull(pts)
        col = {"segA":"#7a5a3a","segB":"#6b4d30","headA":"#8a6a45","headB":"#7d5e3c","throat":"#222","tooth":"#eee"}[kind]
        ax.add_patch(Polygon(pts[h.vertices], closed=True, fc=col, ec="k", lw=0.3, alpha=0.75))
    ax.set_aspect("equal"); ax.set_xlim(-8, 20); ax.set_ylim(-14, 14); ax.set_title(title, fontsize=8)
    ax.grid(alpha=.2)

if __name__ == "__main__":
    fig, axs = plt.subplots(2,4, figsize=(20,9))
    axs = axs.ravel()
    parts, info = build_pose(IDLE); print("idle", info, "top", pose_top(parts))
    draw(axs[0], parts, "idle")
    # windup
    wind = KnotSpine(START, [(0,90),(5,90),(11,104),(19,125)])
    p, i = build_pose(wind); print("windup", i); draw(axs[1], p, "windup")
    k = 2
    for R in (5,7,9,11,13):
        sp, err, prm = solve_knot_pose((R, -0.4))
        p, i = build_pose(sp); print("smash", R, "err %.2f"%err, prm, i)
        draw(axs[k], p, f"smash R={R} err={err:.2f} s1={prm[0]:.1f} k={prm[1]:.1f}"); k+=1
    fig.savefig("preview1.png", dpi=60)
