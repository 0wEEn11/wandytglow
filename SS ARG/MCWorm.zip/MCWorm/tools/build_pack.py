"""
Generates the Sandworm datapack.   python3 build_pack.py  ->  ./wormpack_out/
Tweak the CONFIG block, re-run, copy the output folder into your world's datapacks folder.
"""
import json, math, os, shutil
import numpy as np
from worm_geom import *

OUT = os.environ.get("OUT", "wormpack_out")
NS = "wormpack"
FN = f"{OUT}/data/{NS}/function"
OBJ = "sandworm"

# ------------------------------------------------------------------ CONFIG
TURN_RATE_DEG = 8            # max degrees turned per idle update (every 4 ticks)
IDLE_UPDATE_TICKS = 4        # how often idle re-aims (matches teleport_duration => smooth)
TP_DURATION = 4              # display teleport interpolation (ticks)
FRAME_TICKS = 4              # ticks per burrow/emerge keyframe
FRAME_STEP = 3.5             # max blocks of travel along the arch per keyframe
SMASH_BINS = [5, 7, 9, 11, 13]
SLIDE_BINS = [0, 3, 6, 9, 12]
SMASH_DAMAGE, SMASH_RADIUS = 14, 3.5
SLIDE_DAMAGE, SLIDE_RADIUS = 10, 3.4
SAND = 'block{block_state:"minecraft:sand"}'      # particle block (change to red_sand etc.)
# form-fitting hitbox: a chain of small interaction boxes along the spine  (arclength s, box size)
HITBOXES = [(2.8, 3.4), (4.4, 3.4), (6.0, 3.4), (7.6, 3.4), (9.2, 3.4), (10.8, 3.4), (12.4, 3.4), (13.9, 4.2)]
DEFAULT_HP = 200             # worm health when none was set (weapon damage is used per hit)
DMG_MULT_PERCENT = 100       # scale all weapon damage the worm takes (100 = normal)
HIT_COOLDOWN = 10            # ticks after a hit during which further hits are ignored (like mob i-frames)
MAX_PLAYER_RANGE = 80        # worm ignores players farther than this
PACK_FORMAT = 61


def PL(extra=""):            # nearest valid player selector, relative to execution position
    return f"@p[gamemode=!spectator,distance=..{extra or MAX_PLAYER_RANGE}]"


files = {}


def w(path, text):
    files[f"{FN}/{path}.mcfunction"] = text.strip("\n") + "\n"


def sc(op, name, val):        # scoreboard shorthand
    return f"scoreboard players {op} {name} {OBJ} {val}".strip()


# ------------------------------------------------------------------ poses
idle_parts, idle_info = build_pose(IDLE)
ref_q = [mat_to_quat(p["R"]) for p in idle_parts]


def pose_fn(name, parts):
    lines = []
    for i, p in enumerate(parts):
        lines.append(
            f"$execute as @e[type=block_display,tag=ww.p{i}] run data merge entity @s "
            f"{{start_interpolation:0,interpolation_duration:$(d),{transformation_nbt(p, ref_q[i])}}}")
    w(f"pose/{name}", "\n".join(lines))


pose_fn("idle", idle_parts)


def hb_pose(name, spine):
    """Hitbox layout for a pose: tp each box to ^ ^y ^f (run AS the anchor, whose yaw = worm yaw)."""
    lines = []
    for k, (sv, size) in enumerate(HITBOXES):
        z, y, _ = spine(sv)
        lines.append(f"tp @e[type=interaction,tag=ww.hb{k},limit=1] ^ ^{y - size / 2:.2f} ^{z:.2f}")
    w(f"hitbox/{name}", "\n".join(lines))


hb_pose("idle", IDLE)

# --- dive (burrow) & rise (emerge) keyframes along the arch path
u_idle = idle_u_tail()


def path_pose(delta):
    return build_pose(PathSpine(u_idle + delta))[0]


# burrow: slide forward along the path until everything is below the sand
delta = 0.0
burrow_deltas = []
while True:
    delta += FRAME_STEP
    burrow_deltas.append(delta)
    if pose_top(path_pose(delta)) < -0.3:
        break
# emerge: mirror -> start fully buried on the vertical run, climb back to idle
d_e = 0.0
while pose_top(path_pose(d_e)) >= -0.3:
    d_e -= 0.25
n_up = math.ceil(-d_e / FRAME_STEP)
emerge_deltas = [d_e + (-d_e) * i / n_up for i in range(0, n_up + 1)]     # d_e ... 0

for i, dl in enumerate(burrow_deltas, 1):
    pose_fn(f"burrow_{i}", path_pose(dl))
pose_fn("emerge_0", path_pose(emerge_deltas[0]))
for i, dl in enumerate(emerge_deltas[1:-1], 1):
    pose_fn(f"emerge_{i}", path_pose(dl))
N_EM = len(emerge_deltas) - 1        # last keyframe == idle
N_BU = len(burrow_deltas)

# find keyframe where the head first dips under the sand (for entry dust)
def head_y(dl):
    return build_pose(PathSpine(u_idle + dl))[1]["head_y"]
head_dive_frame = next((i for i, dl in enumerate(burrow_deltas, 1) if head_y(dl) < 1.0), 2)
entry_fwd = PATH_Z0 + 2 * ARCH_R          # where the worm enters the sand on the far side of the arch

# --- windup
wind = KnotSpine(START, [(0, 90), (5, 90), (11, 104), (19, 125)])
pose_fn("windup", build_pose(wind)[0])
hb_pose("windup", wind)

# --- smash poses (one per reach bin)
smash_info = {}
for R in SMASH_BINS:
    sp, dz0, prm, err = solve_smash(R)
    parts, info = build_pose(sp)
    pose_fn(f"smash_{R}", parts)
    hb_pose(f"smash_{R}", sp)
    smash_info[R] = (dz0, err, info)
    assert err < 0.1, f"smash {R} did not solve ({err})"

# --- slide poses
slide_sp, _ = slide_spine()
slide_parts, slide_info = build_pose(slide_sp)
SLIDE_TIP = slide_info["tip_z"]
pose_fn("slide_0", slide_parts)
hb_pose("slide_0", slide_sp)
for T in SLIDE_BINS:
    if T:
        pose_fn(f"slide_{T}", shifted(slide_parts, dz=float(T)))
        hb_pose(f"slide_{T}", ShiftedSpine(slide_sp, dz=float(T)))

# ------------------------------------------------------------------ pack meta
def jw(path, obj):
    files[path] = json.dumps(obj, indent=2) + "\n"


jw(f"{OUT}/pack.mcmeta", {"pack": {
    "description": "Sandworm - display-entity worm with idle tracking, burrow, emerge, smash, slide",
    "min_format": 88,
    "max_format": 999}})
jw(f"{OUT}/data/minecraft/tags/function/load.json", {"values": [f"{NS}:load"]})
jw(f"{OUT}/data/minecraft/tags/function/tick.json", {"values": [f"{NS}:tick"]})

# ------------------------------------------------------------------ core
w("load", f"""
scoreboard objectives add {OBJ} dummy
execute unless score #state {OBJ} matches 0.. run {sc('set', '#state', 0)}
execute unless score #act {OBJ} matches 0.. run {sc('set', '#act', 0)}
execute unless score #yaw {OBJ} matches -180..180 run {sc('set', '#yaw', 0)}
execute unless score #maxhp {OBJ} matches 1.. run {sc('set', '#maxhp', DEFAULT_HP)}
execute unless score #hp {OBJ} matches -1000000.. run {sc('set', '#hp', DEFAULT_HP)}
execute unless score #dmgmult {OBJ} matches 1.. run {sc('set', '#dmgmult', DMG_MULT_PERCENT)}
execute unless score #hitcd {OBJ} matches 0.. run {sc('set', '#hitcd', 0)}
{sc('set', '#k50', 50)}
{sc('set', '#k10000', 10000)}
execute unless score #dead {OBJ} matches 0.. run {sc('set', '#dead', 0)}
{sc('set', '#rate', TURN_RATE_DEG)}
{sc('set', '#nrate', -TURN_RATE_DEG)}
""")

# state: 0 = no worm (burrowed / never summoned), 1 = idle, 2 = performing an action
w("tick", f"""
execute unless score #state {OBJ} matches 1.. run return 0
execute if score #hitcd {OBJ} matches 1.. run {sc('remove', '#hitcd', 1)}
function {NS}:health/poll
execute if score #state {OBJ} matches 1 run return run function {NS}:idle/tick
function {NS}:act/tick
""")

# ------------------------------------------------------------------ idle
w("idle/tick", f"""
{sc('add', '#c', 1)}
execute if score #c {OBJ} matches {IDLE_UPDATE_TICKS}.. run function {NS}:idle/update
""")
w("idle/update", f"""
{sc('set', '#c', 0)}
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s if entity {PL()} run function {NS}:idle/turn
""")
# runs AS the anchor, AT the pivot
w("idle/turn", f"""
tp @s ~ ~ ~ facing entity {PL()} feet
execute store result score #tgt {OBJ} run data get entity @s Rotation[0] 1
scoreboard players operation #d {OBJ} = #tgt {OBJ}
scoreboard players operation #d {OBJ} -= #yaw {OBJ}
execute if score #d {OBJ} matches 181.. run {sc('remove', '#d', 360)}
execute if score #d {OBJ} matches ..-181 run {sc('add', '#d', 360)}
execute if score #d {OBJ} > #rate {OBJ} run scoreboard players operation #d {OBJ} = #rate {OBJ}
execute if score #d {OBJ} < #nrate {OBJ} run scoreboard players operation #d {OBJ} = #nrate {OBJ}
execute if score #d {OBJ} matches 0 run return 0
scoreboard players operation #yaw {OBJ} += #d {OBJ}
execute if score #yaw {OBJ} matches 181.. run {sc('remove', '#yaw', 360)}
execute if score #yaw {OBJ} matches ..-181 run {sc('add', '#yaw', 360)}
function {NS}:util/apply_yaw
function {NS}:hitbox/idle
""")

# ------------------------------------------------------------------ utilities
w("util/apply_yaw", f"""
execute store result storage {NS}:data args.yaw int 1 run scoreboard players get #yaw {OBJ}
function {NS}:util/apply_yaw_m with storage {NS}:data args
""")
w("util/apply_yaw_m", f"""
$tp @e[type=block_display,tag=ww.part] ~ ~ ~ $(yaw) 0
$tp @s ~ ~ ~ $(yaw) 0
""")
w("util/tpdur", f"""
$execute as @e[type=block_display,tag=ww.part] run data merge entity @s {{teleport_duration:$(n)}}
""")
# AS anchor AT pivot: snap the worm to face the nearest player (no rate limit)
w("util/aim", f"""
tp @s ~ ~ ~ facing entity {PL()} feet
execute store result score #yaw {OBJ} run data get entity @s Rotation[0] 1
function {NS}:util/apply_yaw
""")
w("util/face_or_keep", f"""
execute if entity {PL()} run return run function {NS}:util/aim
function {NS}:util/apply_yaw
""")

spawn = []
for i, (blk, kind, ex) in enumerate(PARTS):
    spawn.append(
        f'summon minecraft:block_display ~ ~ ~ {{Tags:["ww.part","ww.p{i}"],'
        f'block_state:{{Name:"{blk}"}},teleport_duration:{TP_DURATION},view_range:3f}}')
w("util/spawn_parts", "\n".join(spawn))

HB_SPAWN = "\n".join(
    f'summon minecraft:interaction ~ ~300 ~ {{Tags:["ww.hitbox","ww.hb{k}"],width:{sz}f,height:{sz}f,response:false}}'
    for k, (sv, sz) in enumerate(HITBOXES))
w("hitbox/hide", "tp @e[type=interaction,tag=ww.hitbox] ~ ~300 ~")
w("util/spawn_worm", f"""
kill @e[type=block_display,tag=ww.part]
kill @e[type=marker,tag=ww.anchor]
kill @e[type=interaction,tag=ww.hitbox]
summon minecraft:marker ~ ~ ~ {{Tags:["ww.anchor"]}}
{HB_SPAWN}
execute unless score #hp {OBJ} matches 1.. run scoreboard players operation #hp {OBJ} = #maxhp {OBJ}
{sc('set', '#dead', 0)}
{sc('set', '#hitcd', 0)}
function {NS}:util/spawn_parts
execute if data storage {NS}:data blocks run function {NS}:util/apply_blocks with storage {NS}:data blocks
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s run function {NS}:util/face_or_keep
""")
w("util/summon_core", f"""
function {NS}:util/spawn_worm
function {NS}:pose/idle {{d:0}}
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s run function {NS}:hitbox/idle
{sc('set', '#state', 1)}
{sc('set', '#act', 0)}
{sc('set', '#c', 0)}
""")
w("util/emerge_core", f"""
function {NS}:util/spawn_worm
function {NS}:pose/emerge_0 {{d:0}}
{sc('set', '#state', 2)}
{sc('set', '#act', 2)}
{sc('set', '#t', 0)}
""")
# ------------------------------------------------------------------ public entry points (command blocks)
w("summon", f"""
execute unless score #state {OBJ} matches 0 run return 0
execute align xyz positioned ~0.5 ~ ~0.5 run function {NS}:util/summon_core
""")
w("emerge_here", f"""
execute unless score #state {OBJ} matches 0 run return 0
execute align xyz positioned ~0.5 ~ ~0.5 run function {NS}:util/emerge_core
""")
w("emerge", f"""
$execute positioned $(x) $(y) $(z) run function {NS}:emerge_here
""")
w("burrow", f"""
execute unless score #state {OBJ} matches 1 run return 0
execute unless entity @e[type=marker,tag=ww.anchor] run return 0
{sc('set', '#state', 2)}
{sc('set', '#act', 1)}
{sc('set', '#t', 0)}
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s run function {NS}:hitbox/hide
""")
for name, act in (("smash", 3), ("slide", 4)):
    w(name, f"""
execute unless score #state {OBJ} matches 1 run return 0
execute unless entity @e[type=marker,tag=ww.anchor] run return 0
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s unless entity {PL()} run return 0
{sc('set', '#state', 2)}
{sc('set', '#act', act)}
{sc('set', '#t', 0)}
""")
w("remove", f"""
kill @e[type=interaction,tag=ww.hitbox]
{sc('set', '#dead', 0)}
kill @e[type=block_display,tag=ww.part]
kill @e[type=marker,tag=ww.anchor]
{sc('set', '#state', 0)}
{sc('set', '#act', 0)}
""")

# ------------------------------------------------------------------ set_blocks
# function wormpack:set_blocks {body:"minecraft:mud",teeth:"minecraft:bone_block",throat:"minecraft:blackstone"}
w("set_blocks", f"""
$data modify storage {NS}:data blocks set value {{body:"$(body)",teeth:"$(teeth)",throat:"$(throat)"}}
function {NS}:util/apply_blocks with storage {NS}:data blocks
""")
_ab = []
for i, (blk, kind, ex) in enumerate(PARTS):
    key = "throat" if kind == "throat" else ("teeth" if kind == "tooth" else "body")
    _ab.append(f'$execute as @e[type=block_display,tag=ww.p{i}] run data modify entity @s block_state set value {{Name:"$({key})"}}')
w("util/apply_blocks", "\n".join(_ab))

# ------------------------------------------------------------------ health
# function wormpack:set_health {hp:20}
w("set_health", f"""
$scoreboard players set #hp {OBJ} $(hp)
execute if score #hp {OBJ} matches 1.. run scoreboard players operation #maxhp {OBJ} = #hp {OBJ}
function {NS}:health/check
""")
# any context: react to health <= 0
w("health/check", f"""
execute unless score #hp {OBJ} matches ..0 run return 0
execute if score #state {OBJ} matches 2 run return run scoreboard players set #dead {OBJ} 1
execute if score #state {OBJ} matches 1 run function {NS}:health/kill_now
""")
w("health/poll", f"""
execute as @e[type=interaction,tag=ww.hitbox] at @s if data entity @s attack run function {NS}:health/on_attack
""")
# AS the hitbox AT the hitbox. Hits count while idle, smashing or sliding; the worm is untouchable
# while burrowing/emerging (mostly underground) or already dead.
w("health/on_attack", f"""
data modify storage {NS}:data att.uuid set from entity @s attack.player
data remove entity @s attack
execute if score #state {OBJ} matches 2 if score #act {OBJ} matches 1..2 run return 0
execute if score #hp {OBJ} matches ..0 run return 0
execute if score #hitcd {OBJ} matches 1.. run return 0
function {NS}:health/find_attacker with storage {NS}:data att
""")
# find the player who hit (by UUID) and run apply_hit as them (position stays at the hitbox)
w("health/find_attacker", f"""
$execute as @a[nbt={{UUID:$(uuid)}},limit=1] run function {NS}:health/apply_hit
""")
# AS the attacker, AT the hitbox.  damage taken = attacker's attack_damage attribute
# (held weapon + Strength/Weakness) + Sharpness, x #dmgmult%, rounded, minimum 1
w("health/apply_hit", f"""
execute store result score #dmg {OBJ} run attribute @s minecraft:attack_damage get 100
scoreboard players set #sharp {OBJ} 0
execute store result score #sharp {OBJ} run data get entity @s SelectedItem.components."minecraft:enchantments"."minecraft:sharpness" 1
execute if score #sharp {OBJ} matches 1.. run scoreboard players operation #sharp {OBJ} *= #k50 {OBJ}
execute if score #sharp {OBJ} matches 1.. run scoreboard players add #sharp {OBJ} 50
scoreboard players operation #dmg {OBJ} += #sharp {OBJ}
scoreboard players operation #dmg {OBJ} *= #dmgmult {OBJ}
scoreboard players add #dmg {OBJ} 5000
scoreboard players operation #dmg {OBJ} /= #k10000 {OBJ}
execute if score #dmg {OBJ} matches ..0 run scoreboard players set #dmg {OBJ} 1
scoreboard players operation #hp {OBJ} -= #dmg {OBJ}
scoreboard players set #hitcd {OBJ} {HIT_COOLDOWN}
playsound minecraft:entity.iron_golem.damage hostile @a ~ ~ ~ 3 0.5
particle minecraft:damage_indicator ~ ~1.7 ~ 0.8 0.8 0.8 0.1 8 force
particle {SAND} ~ ~1.7 ~ 1 1 1 0.05 25 force
function {NS}:health/check
""")
w("health/kill_now", f"""
{sc('set', '#dead', 0)}
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s run function {NS}:health/explode
function {NS}:burrow
""")
# AS the anchor AT the pivot: explosions along the body (no block damage, particles only)
_ex = []
for f_, h_ in ((3.0, 8.0), (-2.0, 5.0), (0.5, 10.5), (-2.5, 2.0)):
    _ex.append(f"execute rotated ~ 0 positioned ^ ^{h_} ^{f_} run particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1 force")
    _ex.append(f"execute rotated ~ 0 positioned ^ ^{h_} ^{f_} run particle minecraft:explosion ~ ~ ~ 1.2 1.2 1.2 0 6 force")
_ex.append("playsound minecraft:entity.generic.explode hostile @a ~ ~4 ~ 6 0.5")
_ex.append("playsound minecraft:entity.generic.explode hostile @a ~ ~8 ~ 6 0.8")
_ex.append("playsound minecraft:entity.warden.death hostile @a ~ ~ ~ 6 0.6")
w("health/explode", "\n".join(_ex))

# ------------------------------------------------------------------ bossbar
# Put `function wormpack:bossbar` in a REPEATING, ALWAYS ACTIVE command block.
# Set the title with:  function wormpack:bossbar_name {name:"Sand Worm"}
BOSSBAR_RANGE = 96           # players within this many blocks of the worm see the bar
BB = "wormpack:health"
BB_VERSION = 2               # #bb == 2 means "bar exists in the current format" (older bars get rebuilt)
w("bossbar_init", f"""
bossbar add {BB} "Sandworm"
bossbar set {BB} color red
bossbar set {BB} style notched_20
execute if data storage {NS}:data bb.name run function {NS}:bossbar_apply_name with storage {NS}:data bb
{sc('set', '#bb', BB_VERSION)}
""")
w("bossbar_reset", f"""
bossbar remove {BB}
function {NS}:bossbar_init
""")
w("bossbar_apply_name", f"""
$bossbar set {BB} name "$(name)"
""")
w("bossbar_name", f"""
$data modify storage {NS}:data bb.name set value "$(name)"
execute unless score #bb {OBJ} matches {BB_VERSION} run function {NS}:bossbar_reset
function {NS}:bossbar_apply_name with storage {NS}:data bb
""")
w("bossbar", f"""
execute unless score #bb {OBJ} matches {BB_VERSION} run function {NS}:bossbar_reset
execute if score #state {OBJ} matches 0 run return run bossbar set {BB} visible false
bossbar set {BB} visible true
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s run bossbar set {BB} players @a[distance=..{BOSSBAR_RANGE}]
scoreboard players operation #bbv {OBJ} = #hp {OBJ}
execute if score #bbv {OBJ} matches ..-1 run scoreboard players set #bbv {OBJ} 0
execute store result bossbar {BB} max run scoreboard players get #maxhp {OBJ}
execute store result bossbar {BB} value run scoreboard players get #bbv {OBJ}
""")
# delete the bar (it is rebuilt automatically the next time `bossbar` runs)
w("bossbar_off", f"""
bossbar remove {BB}
{sc('set', '#bb', 0)}
""")

# ------------------------------------------------------------------ action dispatcher
w("act/tick", f"""
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s run function {NS}:act/dispatch
""")
w("act/dispatch", f"""
{sc('add', '#t', 1)}
execute if score #act {OBJ} matches 1 run function {NS}:act/burrow
execute if score #act {OBJ} matches 2 run function {NS}:act/emerge
execute if score #act {OBJ} matches 3 run function {NS}:act/smash
execute if score #act {OBJ} matches 4 run function {NS}:act/slide
""")


def at(t, cmd):
    return f"execute if score #t {OBJ} matches {t} run {cmd}"


def dust(spread="2.5 0.4 2.5", speed="0.25", count=90, dy="0.3"):
    return f"particle {SAND} ~ ~{dy} ~ {spread} {speed} {count} force"


def dust_ahead(fwd, spread="2 0.4 2", speed="0.25", count=90):
    return (f"execute rotated ~ 0 positioned ^ ^ ^{fwd:.2f} run "
            f"particle {SAND} ~ ~0.3 ~ {spread} {speed} {count} force")


# ------------------------------------------------------------------ BURROW
L = []
L.append(at(1, "playsound minecraft:entity.warden.dig hostile @a ~ ~ ~ 4 0.5"))
L.append(at(1, "playsound minecraft:entity.ravager.roar hostile @a ~ ~ ~ 4 0.6"))
L.append(at(1, dust(count=60)))
t_frame = {}
for i in range(1, N_BU + 1):
    t = 2 + FRAME_TICKS * (i - 1)
    t_frame[i] = t
    L.append(at(t, f"function {NS}:pose/burrow_{i} {{d:{FRAME_TICKS}}}"))
t_hit = t_frame[head_dive_frame] + FRAME_TICKS
for k, tt in enumerate(range(t_hit, t_hit + FRAME_TICKS * 5, FRAME_TICKS)):
    L.append(at(tt, dust_ahead(entry_fwd, count=110 if k == 0 else 60)))
    if k == 0:
        L.append(at(tt, "playsound minecraft:block.sand.break hostile @a ~ ~ ~ 4 0.5"))
t_end = t_frame[N_BU] + FRAME_TICKS + 1
L.append(at(t_end, dust(count=80)))
L.append(at(t_end, f"function {NS}:act/burrow_done"))
w("act/burrow", "\n".join(L))
w("act/burrow_done", f"""
kill @e[type=interaction,tag=ww.hitbox]
{sc('set', '#dead', 0)}
kill @e[type=block_display,tag=ww.part]
kill @e[type=marker,tag=ww.anchor]
{sc('set', '#state', 0)}
{sc('set', '#act', 0)}
""")

# ------------------------------------------------------------------ EMERGE
L = []
t0 = 3
L.append(at(1, "playsound minecraft:entity.warden.emerge hostile @a ~ ~ ~ 5 0.5"))
L.append(at(t0, dust(count=120)))
for i in range(1, N_EM + 1):
    t = t0 + FRAME_TICKS * (i - 1)
    pose = "idle" if i == N_EM else f"emerge_{i}"
    L.append(at(t, f"function {NS}:pose/{pose} {{d:{FRAME_TICKS}}}"))
    if i > 1:
        L.append(at(t, dust(count=70, spread="2.2 0.4 2.2")))
t_done = t0 + FRAME_TICKS * N_EM
L.append(at(t_done, "playsound minecraft:entity.ravager.roar hostile @a ~ ~ ~ 6 0.5"))
L.append(at(t_done, dust(count=100, spread="3 0.5 3")))
L.append(at(t_done, f"function {NS}:act/finish"))
w("act/emerge", "\n".join(L))

w("act/finish", f"""
{sc('set', '#state', 1)}
{sc('set', '#act', 0)}
{sc('set', '#c', 0)}
function {NS}:hitbox/idle
execute if score #dead {OBJ} matches 1 if score #hp {OBJ} matches ..0 run function {NS}:health/kill_now
{sc('set', '#dead', 0)}
""")

# ------------------------------------------------------------------ SMASH
T_AIM, T_STRIKE, T_HIT, T_HOLD_END = 1, 11, 15, 27
L = []
L.append(at(T_AIM, f"function {NS}:util/tpdur {{n:10}}"))
L.append(at(T_AIM, f"function {NS}:util/aim"))
L.append(at(T_AIM, f"function {NS}:pose/windup {{d:10}}"))
L.append(at(T_AIM, "playsound minecraft:entity.ravager.roar hostile @a ~ ~ ~ 5 0.6"))
L.append(at(T_STRIKE, f"function {NS}:util/tpdur {{n:{TP_DURATION}}}"))
L.append(at(T_STRIKE, f"function {NS}:util/aim"))
L.append(at(T_STRIKE, f"function {NS}:act/smash_pick"))
for R in SMASH_BINS:
    L.append(at(T_STRIKE, f"execute if score #bin {OBJ} matches {R} run function {NS}:pose/smash_{R} {{d:4}}"))
L.append(f"execute if score #t {OBJ} matches {T_HIT}..{T_HIT+1} run function {NS}:act/smash_hit")
L.append(at(T_HIT, f"function {NS}:act/smash_fx"))
L.append(at(T_HIT + 5, f"function {NS}:act/smash_fx_small"))
L.append(at(6, f"function {NS}:hitbox/windup"))
for R in SMASH_BINS:
    L.append(at(13, f"execute if score #bin {OBJ} matches {R} run function {NS}:hitbox/smash_{R}"))
L.append(at(T_HOLD_END + 12, f"function {NS}:hitbox/idle"))
L.append(at(T_HOLD_END, f"function {NS}:pose/idle {{d:24}}"))
L.append(at(T_HOLD_END + 25, f"function {NS}:act/finish"))
w("act/smash", "\n".join(L))

P = []
P.append(f"{sc('set', '#bin', SMASH_BINS[-1])}")
for R_lo, R_hi in reversed(list(zip(SMASH_BINS[:-1], SMASH_BINS[1:]))):
    mid = (R_lo + R_hi) / 2
    P.append(f"execute if entity {PL(str(mid))} run {sc('set', '#bin', R_lo)}")
w("act/smash_pick", "\n".join(P))

H, F, S = [], [], []
for R in SMASH_BINS:
    H.append(f"execute if score #bin {OBJ} matches {R} rotated ~ 0 positioned ^ ^ ^{R} run "
             f"damage @a[gamemode=!spectator,distance=..{SMASH_RADIUS}] {SMASH_DAMAGE} minecraft:mob_attack by @e[type=marker,tag=ww.anchor,limit=1]")
    F.append(f"execute if score #bin {OBJ} matches {R} rotated ~ 0 positioned ^ ^ ^{R} run function {NS}:act/impact_fx")
    S.append(f"execute if score #bin {OBJ} matches {R} rotated ~ 0 positioned ^ ^ ^{R} run particle {SAND} ~ ~0.5 ~ 1.5 0.3 1.5 0.15 40 force")
w("act/smash_hit", "\n".join(H))
w("act/smash_fx", "\n".join(F))
w("act/smash_fx_small", "\n".join(S))
w("act/impact_fx", f"""
particle {SAND} ~ ~0.5 ~ 1.8 0.5 1.8 0.45 220 force
particle minecraft:explosion ~ ~0.3 ~ 0.6 0.1 0.6 0 4 force
playsound minecraft:entity.generic.explode hostile @a ~ ~ ~ 5 0.6
playsound minecraft:block.sand.break hostile @a ~ ~ ~ 5 0.5
""")

# ------------------------------------------------------------------ SLIDE
T_TURN, T_GO, T_ARRIVE, T_HIT0, T_HIT1, T_BACK = 1, 11, 23, 21, 29, 33
L = []
L.append(at(T_TURN, f"function {NS}:util/tpdur {{n:10}}"))
L.append(at(T_TURN, f"function {NS}:util/aim"))
L.append(at(T_TURN, f"function {NS}:pose/slide_0 {{d:10}}"))
L.append(at(T_TURN, "playsound minecraft:entity.ravager.roar hostile @a ~ ~ ~ 5 0.5"))
L.append(at(T_TURN, dust(count=60)))
L.append(at(T_GO, f"function {NS}:util/tpdur {{n:{TP_DURATION}}}"))
L.append(at(T_GO, f"function {NS}:util/aim"))
L.append(at(T_GO, f"function {NS}:act/slide_pick"))
for T in SLIDE_BINS:
    if T:
        L.append(at(T_GO, f"execute if score #bin {OBJ} matches {T} run function {NS}:pose/slide_{T} {{d:12}}"))
L.append(at(T_GO, "playsound minecraft:entity.warden.dig hostile @a ~ ~ ~ 5 0.4"))
for tt in range(T_GO + 2, T_ARRIVE, 3):                      # sand kicked up along the path
    L.append(at(tt, f"function {NS}:act/slide_trail"))
L.append(f"execute if score #t {OBJ} matches {T_HIT0}..{T_HIT1} run function {NS}:act/slide_hit")
L.append(at(T_ARRIVE, f"function {NS}:act/slide_fx"))
L.append(at(6, f"function {NS}:hitbox/slide_0"))
for T in SLIDE_BINS:
    if T:
        L.append(at(17, f"execute if score #bin {OBJ} matches {T} run function {NS}:hitbox/slide_{T}"))
L.append(at(T_BACK + 13, f"function {NS}:hitbox/idle"))
L.append(at(T_BACK, f"function {NS}:pose/idle {{d:26}}"))
L.append(at(T_BACK + 27, f"function {NS}:act/finish"))
w("act/slide", "\n".join(L))

P = [sc('set', '#bin', SLIDE_BINS[-1])]
for T in reversed(SLIDE_BINS[:-1]):
    P.append(f"execute if entity {PL(f'{SLIDE_TIP + T + 1.5:.1f}')} run {sc('set', '#bin', T)}")
w("act/slide_pick", "\n".join(P))

H, F, TR = [], [], []
for T in SLIDE_BINS:
    tip = SLIDE_TIP + T
    for back in (0.0, 4.0, 8.0):
        H.append(f"execute if score #bin {OBJ} matches {T} rotated ~ 0 positioned ^ ^ ^{tip - back:.2f} run "
                 f"damage @a[gamemode=!spectator,distance=..{SLIDE_RADIUS}] {SLIDE_DAMAGE} minecraft:mob_attack by @e[type=marker,tag=ww.anchor,limit=1]")
    F.append(f"execute if score #bin {OBJ} matches {T} rotated ~ 0 positioned ^ ^ ^{tip:.2f} run function {NS}:act/impact_fx")
    for frac in (0.0, 0.5, 1.0):
        TR.append(f"execute if score #bin {OBJ} matches {T} rotated ~ 0 positioned ^ ^ ^{SLIDE_TIP - 6 + T * frac:.2f} run "
                  f"particle {SAND} ~ ~0.2 ~ 1.8 0.2 1.8 0.1 25 force")
w("act/slide_hit", "\n".join(H))
w("act/slide_fx", "\n".join(F))
w("act/slide_trail", "\n".join(TR))

# ------------------------------------------------------------------ write out
if os.path.exists(OUT):
    shutil.rmtree(OUT)
for path, text in files.items():
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="\n") as fh:
        fh.write(text)

print("files:", len(files), "| parts per pose:", N_PARTS)
print("burrow frames:", N_BU, "| emerge frames:", N_EM, "| head dives at frame", head_dive_frame)
print("slide tip z:", round(SLIDE_TIP, 2))
for R, (dz0, err, info) in smash_info.items():
    print("smash", R, "tail shift", dz0, "tip", round(info["tip_z"], 2), round(info["tip_y"], 2))
