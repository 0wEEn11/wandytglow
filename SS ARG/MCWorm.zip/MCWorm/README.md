# Sandworm datapack

A 16-block-long, ~2-block-radius sandworm made of **mud** block-display entities.
It idles with only its head/neck tracking the nearest player, and does four
button-triggered moves. After every move it returns to the idle stance.

## Install
1. Delete any older `SandwormDatapack` from your world's `datapacks` folder.
2. Drop this zip (or its unzipped folder) into `<world>/datapacks/`, then run `/reload`.
3. One-time cleanup of leftovers from the very first version: `/kill @e[type=marker,tag=ww.part]`
4. Optional, stops chat spam from command blocks: `/gamerule commandBlockOutput false`

`pack.mcmeta` uses `min_format`/`max_format` (Minecraft 1.21.9 and newer). On an older
version it needs `pack_format` instead; the commands themselves need 1.21+.

## Command blocks (one per button)
Use *Impulse / Needs Redstone* command blocks, each wired to its own button.

| Purpose | Command |
|---|---|
| Place the worm instantly (first-time setup) | `function wormpack:summon` |
| Burrow | `function wormpack:burrow` |
| Emerge at coordinates | `function wormpack:emerge {x:100,y:64,z:-30}` |
| Smash the front into the sand at the nearest player | `function wormpack:smash` |
| Slide along the sand to ram the nearest player | `function wormpack:slide` |
| Change the worm's blocks | `function wormpack:set_blocks {body:"minecraft:mud",teeth:"minecraft:bone_block",throat:"minecraft:blackstone"}` |
| Set the worm's health | `function wormpack:set_health {hp:20}` |
| Health bossbar (**repeating, always-active** command block) | `function wormpack:bossbar` |
| Set the bossbar's name | `function wormpack:bossbar_name {name:"Shai-Hulud"}` |
| Emergency reset / delete the worm | `function wormpack:remove` |

* `summon` puts the worm at the command block's own position. `emerge` uses the
  x/y/z you give (whole numbers are fine; it centres itself on that block).
* **y is the air block sitting directly on top of the sand**: the worm's base is
  at the bottom of that block. If the worm appears one block too high or low, adjust y.
* Emerge only works while the worm is burrowed; burrow/smash/slide only work while it
  is idle. Pressing a button mid-move does nothing, so buttons can't interrupt each other.
* Smash and slide need a player within 80 blocks; otherwise the button is ignored.
* `set_blocks` changes the body, teeth and throat blocks on the live worm immediately. The choice
  is remembered, so the worm keeps it after burrowing and emerging again. It also works while the
  worm is burrowed (it applies on the next emerge). Use exact block ids; a misspelled id makes that
  part vanish. The throat piece is turned so the block's TOP face points out of the mouth, so it shows the top
  texture. Blocks are used with default properties, so logs/pillars won't rotate.

## Hitbox and health
* The hitbox is a chain of 8 small invisible attackable boxes (`interaction` entities, 3.4 blocks each,
  4.2 for the head) that follow the worm's spine. They turn with the worm, and switch to match the
  windup, smash, slide and idle poses (roughly halfway through each transition). While the worm is
  burrowed or diving/erupting the boxes are parked high above the world so they don't block your clicks.
  See `tools/hitbox_preview.png`.
* Boxes can't rotate in Minecraft, so at diagonal facings each one is slightly wider than the body.
  Sizes/spacing: `HITBOXES` in `tools/build_pack.py`.
* Hits count while idle, smashing or sliding, and are ignored during burrow/emerge.
* **Weapon damage matters.** Each hit takes health equal to the attacker's `attack_damage` (whatever they are
  holding, plus Strength/Weakness effects) plus Sharpness (+0.5 per level, +0.5 extra), rounded, minimum 1.
  Examples: fist 1, wooden sword 4, diamond sword 7, netherite sword 8, diamond sword with Sharpness V 10.
  Any item with a custom attack_damage modifier works too. Scale it with `/scoreboard players set #dmgmult sandworm 150`
  (percent, default 100). Hits within 10 ticks of the last one are ignored (like mob invulnerability frames),
  so spam-clicking with fists doesn't beat a real weapon; change `HIT_COOLDOWN` in `tools/build_pack.py`.
  Attack-cooldown charge and critical hits are not detectable, so they don't change the damage.
* The default health is now 200 for a new setup. An existing world keeps its old value, so run `function wormpack:set_health {hp:200}`.
* `set_health {hp:N}` sets current health, and also the "full health" the worm respawns with (when N is above 0).
  Read it with `/scoreboard players get #hp sandworm`.
* At 0 health (from hits or from `set_health {hp:0}`) it blows up in explosion particles and burrows.
  If that happens mid-move, it finishes the move first, then explodes and burrows. Explosions are particles
  only, so no blocks are destroyed.
* Emerging again after death restores full health. A worm that burrowed normally keeps its current health.

## Bossbar
Put `function wormpack:bossbar` in a **Repeating, Always Active** command block. It creates the bar the first
time and keeps it filled to match the worm's health. The title is just the name (no numbers).
Players within 96 blocks of the worm see it; it hides while the worm is burrowed and is empty when the worm dies.

Set the name with `function wormpack:bossbar_name {name:"Shai-Hulud"}` (run it from any command block or chat, once).
The name is remembered across reloads and restarts. Don't put double quotes inside the name. Until you set one, the
title is "Sandworm". A bar made by an older version of this pack is rebuilt automatically the first time
`bossbar` runs. `function wormpack:bossbar_off` deletes the bar (it comes back, with your name, next time `bossbar` runs).
Colour/style: edit `bossbar_init.mcfunction`, then run `bossbar_off`. Range: `BOSSBAR_RANGE` in `tools/build_pack.py`.

## What each move does
* **Idle**: every 4 ticks it turns up to 8° toward the nearest player, and the client
  interpolates each update, so the turn looks continuous (about 40°/second max).
* **Burrow**: dives head-first along its own arch into the sand, then all its entities are deleted.
* **Emerge**: erupts straight up from the coordinates, arches over, settles into idle facing the nearest player.
* **Smash**: rears back, then slams its head into the sand where the nearest player is standing
  (reach 5-13 blocks). Damages players within 3.5 blocks of the impact.
* **Slide**: drops low, skims up to 12 blocks toward the nearest player, rams, then slides back.

## Why it's cheap on lag
* 29 `block_display` entities total. No armor stands, no per-tick teleporting, no passengers.
* Everything sits at one pivot, so turning is one `tp` of yaw and the client smooths it.
* Moves are a handful of keyframes that the client interpolates between.
* When burrowed the datapack does one scoreboard check per tick and nothing else.

## Tweaking
Everything is generated. Edit the CONFIG at the top of `tools/build_pack.py` (shape constants in
`tools/worm_geom.py`), then run `cd tools && python3 build_pack.py` (needs numpy + scipy) and copy
the new `wormpack_out` over the pack. Turn speed in-game:
`/scoreboard players set #rate sandworm 8` and `... #nrate sandworm -8` (same number, negated).

## Not yet tested in-game
* **Facing**: the head should point at you. If it points directly away, tell me.
* **Sand height**: if the worm floats or is sunk, move the y of the summon/emerge position by 1.
