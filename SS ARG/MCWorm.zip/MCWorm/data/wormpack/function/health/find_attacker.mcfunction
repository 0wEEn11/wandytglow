$execute as @a[nbt={UUID:$(uuid)},limit=1] run function wormpack:health/apply_hit
