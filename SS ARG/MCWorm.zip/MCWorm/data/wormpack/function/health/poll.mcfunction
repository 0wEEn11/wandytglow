execute as @e[type=interaction,tag=ww.hitbox] at @s if data entity @s attack run function wormpack:health/on_attack
