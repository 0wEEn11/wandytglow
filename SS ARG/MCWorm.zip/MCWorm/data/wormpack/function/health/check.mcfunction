execute unless score #hp sandworm matches ..0 run return 0
execute if score #state sandworm matches 2 run return run scoreboard players set #dead sandworm 1
execute if score #state sandworm matches 1 run function wormpack:health/kill_now
