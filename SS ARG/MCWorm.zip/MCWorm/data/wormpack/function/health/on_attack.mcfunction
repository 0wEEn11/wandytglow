data modify storage wormpack:data att.uuid set from entity @s attack.player
data remove entity @s attack
execute if score #state sandworm matches 2 if score #act sandworm matches 1..2 run return 0
execute if score #hp sandworm matches ..0 run return 0
execute if score #hitcd sandworm matches 1.. run return 0
function wormpack:health/find_attacker with storage wormpack:data att
