scoreboard players set #dead sandworm 0
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s run function wormpack:health/explode
function wormpack:burrow
