execute store result score #dmg sandworm run attribute @s minecraft:attack_damage get 100
scoreboard players set #sharp sandworm 0
execute store result score #sharp sandworm run data get entity @s SelectedItem.components."minecraft:enchantments"."minecraft:sharpness" 1
execute if score #sharp sandworm matches 1.. run scoreboard players operation #sharp sandworm *= #k50 sandworm
execute if score #sharp sandworm matches 1.. run scoreboard players add #sharp sandworm 50
scoreboard players operation #dmg sandworm += #sharp sandworm
scoreboard players operation #dmg sandworm *= #dmgmult sandworm
scoreboard players add #dmg sandworm 5000
scoreboard players operation #dmg sandworm /= #k10000 sandworm
execute if score #dmg sandworm matches ..0 run scoreboard players set #dmg sandworm 1
scoreboard players operation #hp sandworm -= #dmg sandworm
scoreboard players set #hitcd sandworm 10
playsound minecraft:entity.iron_golem.damage hostile @a ~ ~ ~ 3 0.5
particle minecraft:damage_indicator ~ ~1.7 ~ 0.8 0.8 0.8 0.1 8 force
particle block{block_state:"minecraft:sand"} ~ ~1.7 ~ 1 1 1 0.05 25 force
function wormpack:health/check
