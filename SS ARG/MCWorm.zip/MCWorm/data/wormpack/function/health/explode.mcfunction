execute rotated ~ 0 positioned ^ ^8.0 ^3.0 run particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1 force
execute rotated ~ 0 positioned ^ ^8.0 ^3.0 run particle minecraft:explosion ~ ~ ~ 1.2 1.2 1.2 0 6 force
execute rotated ~ 0 positioned ^ ^5.0 ^-2.0 run particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1 force
execute rotated ~ 0 positioned ^ ^5.0 ^-2.0 run particle minecraft:explosion ~ ~ ~ 1.2 1.2 1.2 0 6 force
execute rotated ~ 0 positioned ^ ^10.5 ^0.5 run particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1 force
execute rotated ~ 0 positioned ^ ^10.5 ^0.5 run particle minecraft:explosion ~ ~ ~ 1.2 1.2 1.2 0 6 force
execute rotated ~ 0 positioned ^ ^2.0 ^-2.5 run particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1 force
execute rotated ~ 0 positioned ^ ^2.0 ^-2.5 run particle minecraft:explosion ~ ~ ~ 1.2 1.2 1.2 0 6 force
playsound minecraft:entity.generic.explode hostile @a ~ ~4 ~ 6 0.5
playsound minecraft:entity.generic.explode hostile @a ~ ~8 ~ 6 0.8
playsound minecraft:entity.warden.death hostile @a ~ ~ ~ 6 0.6
