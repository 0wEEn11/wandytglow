bossbar remove wormpack:health
function wormpack:bossbar_init
