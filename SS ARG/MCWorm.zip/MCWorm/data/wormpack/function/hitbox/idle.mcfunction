tp @e[type=interaction,tag=ww.hb0,limit=1] ^ ^-0.95 ^-2.50
tp @e[type=interaction,tag=ww.hb1,limit=1] ^ ^0.65 ^-2.50
tp @e[type=interaction,tag=ww.hb2,limit=1] ^ ^2.25 ^-2.50
tp @e[type=interaction,tag=ww.hb3,limit=1] ^ ^3.81 ^-2.24
tp @e[type=interaction,tag=ww.hb4,limit=1] ^ ^5.17 ^-1.41
tp @e[type=interaction,tag=ww.hb5,limit=1] ^ ^6.13 ^-0.14
tp @e[type=interaction,tag=ww.hb6,limit=1] ^ ^6.54 ^1.40
tp @e[type=interaction,tag=ww.hb7,limit=1] ^ ^5.98 ^2.88
