tp @e[type=interaction,tag=ww.hb0,limit=1] ^ ^-3.30 ^-1.52
tp @e[type=interaction,tag=ww.hb1,limit=1] ^ ^-2.36 ^-0.24
tp @e[type=interaction,tag=ww.hb2,limit=1] ^ ^-2.01 ^1.31
tp @e[type=interaction,tag=ww.hb3,limit=1] ^ ^-1.84 ^2.90
tp @e[type=interaction,tag=ww.hb4,limit=1] ^ ^-1.67 ^4.50
tp @e[type=interaction,tag=ww.hb5,limit=1] ^ ^-1.51 ^6.09
tp @e[type=interaction,tag=ww.hb6,limit=1] ^ ^-1.34 ^7.68
tp @e[type=interaction,tag=ww.hb7,limit=1] ^ ^-1.58 ^9.17
