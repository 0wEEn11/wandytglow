tp @e[type=interaction,tag=ww.hb0,limit=1] ^ ^-0.99 ^1.31
tp @e[type=interaction,tag=ww.hb1,limit=1] ^ ^0.39 ^2.11
tp @e[type=interaction,tag=ww.hb2,limit=1] ^ ^1.43 ^3.31
tp @e[type=interaction,tag=ww.hb3,limit=1] ^ ^2.03 ^4.78
tp @e[type=interaction,tag=ww.hb4,limit=1] ^ ^2.12 ^6.37
tp @e[type=interaction,tag=ww.hb5,limit=1] ^ ^1.68 ^7.91
tp @e[type=interaction,tag=ww.hb6,limit=1] ^ ^0.77 ^9.21
tp @e[type=interaction,tag=ww.hb7,limit=1] ^ ^-0.82 ^10.11
