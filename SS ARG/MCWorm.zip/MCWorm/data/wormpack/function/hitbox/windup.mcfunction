tp @e[type=interaction,tag=ww.hb0,limit=1] ^ ^-0.95 ^-2.50
tp @e[type=interaction,tag=ww.hb1,limit=1] ^ ^0.65 ^-2.50
tp @e[type=interaction,tag=ww.hb2,limit=1] ^ ^2.25 ^-2.52
tp @e[type=interaction,tag=ww.hb3,limit=1] ^ ^3.84 ^-2.64
tp @e[type=interaction,tag=ww.hb4,limit=1] ^ ^5.43 ^-2.86
tp @e[type=interaction,tag=ww.hb5,limit=1] ^ ^6.99 ^-3.18
tp @e[type=interaction,tag=ww.hb6,limit=1] ^ ^8.53 ^-3.61
tp @e[type=interaction,tag=ww.hb7,limit=1] ^ ^9.55 ^-4.11
