tp @e[type=interaction,tag=ww.hb0,limit=1] ^ ^-0.95 ^-2.50
tp @e[type=interaction,tag=ww.hb1,limit=1] ^ ^0.61 ^-2.24
tp @e[type=interaction,tag=ww.hb2,limit=1] ^ ^1.92 ^-1.34
tp @e[type=interaction,tag=ww.hb3,limit=1] ^ ^2.72 ^0.03
tp @e[type=interaction,tag=ww.hb4,limit=1] ^ ^2.86 ^1.61
tp @e[type=interaction,tag=ww.hb5,limit=1] ^ ^2.31 ^3.10
tp @e[type=interaction,tag=ww.hb6,limit=1] ^ ^1.18 ^4.22
tp @e[type=interaction,tag=ww.hb7,limit=1] ^ ^-0.62 ^4.73
