tp @e[type=interaction,tag=ww.hb0,limit=1] ^ ^-3.30 ^7.48
tp @e[type=interaction,tag=ww.hb1,limit=1] ^ ^-2.36 ^8.76
tp @e[type=interaction,tag=ww.hb2,limit=1] ^ ^-2.01 ^10.31
tp @e[type=interaction,tag=ww.hb3,limit=1] ^ ^-1.84 ^11.90
tp @e[type=interaction,tag=ww.hb4,limit=1] ^ ^-1.67 ^13.50
tp @e[type=interaction,tag=ww.hb5,limit=1] ^ ^-1.51 ^15.09
tp @e[type=interaction,tag=ww.hb6,limit=1] ^ ^-1.34 ^16.68
tp @e[type=interaction,tag=ww.hb7,limit=1] ^ ^-1.58 ^18.17
