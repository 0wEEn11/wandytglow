tp @e[type=interaction,tag=ww.hb0,limit=1] ^ ^-0.99 ^3.31
tp @e[type=interaction,tag=ww.hb1,limit=1] ^ ^0.39 ^4.11
tp @e[type=interaction,tag=ww.hb2,limit=1] ^ ^1.43 ^5.31
tp @e[type=interaction,tag=ww.hb3,limit=1] ^ ^2.03 ^6.78
tp @e[type=interaction,tag=ww.hb4,limit=1] ^ ^2.12 ^8.37
tp @e[type=interaction,tag=ww.hb5,limit=1] ^ ^1.68 ^9.91
tp @e[type=interaction,tag=ww.hb6,limit=1] ^ ^0.77 ^11.21
tp @e[type=interaction,tag=ww.hb7,limit=1] ^ ^-0.82 ^12.11
