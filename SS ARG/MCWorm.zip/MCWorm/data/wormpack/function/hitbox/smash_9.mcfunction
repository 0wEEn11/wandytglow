tp @e[type=interaction,tag=ww.hb0,limit=1] ^ ^-0.99 ^-0.69
tp @e[type=interaction,tag=ww.hb1,limit=1] ^ ^0.39 ^0.11
tp @e[type=interaction,tag=ww.hb2,limit=1] ^ ^1.43 ^1.31
tp @e[type=interaction,tag=ww.hb3,limit=1] ^ ^2.03 ^2.78
tp @e[type=interaction,tag=ww.hb4,limit=1] ^ ^2.12 ^4.37
tp @e[type=interaction,tag=ww.hb5,limit=1] ^ ^1.68 ^5.91
tp @e[type=interaction,tag=ww.hb6,limit=1] ^ ^0.77 ^7.21
tp @e[type=interaction,tag=ww.hb7,limit=1] ^ ^-0.82 ^8.11
