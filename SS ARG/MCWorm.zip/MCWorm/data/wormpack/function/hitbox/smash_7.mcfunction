tp @e[type=interaction,tag=ww.hb0,limit=1] ^ ^-0.97 ^-2.32
tp @e[type=interaction,tag=ww.hb1,limit=1] ^ ^0.46 ^-1.61
tp @e[type=interaction,tag=ww.hb2,limit=1] ^ ^1.55 ^-0.46
tp @e[type=interaction,tag=ww.hb3,limit=1] ^ ^2.19 ^1.00
tp @e[type=interaction,tag=ww.hb4,limit=1] ^ ^2.28 ^2.59
tp @e[type=interaction,tag=ww.hb5,limit=1] ^ ^1.83 ^4.11
tp @e[type=interaction,tag=ww.hb6,limit=1] ^ ^0.87 ^5.39
tp @e[type=interaction,tag=ww.hb7,limit=1] ^ ^-0.77 ^6.22
