$scoreboard players set #hp sandworm $(hp)
execute if score #hp sandworm matches 1.. run scoreboard players operation #maxhp sandworm = #hp sandworm
function wormpack:health/check
