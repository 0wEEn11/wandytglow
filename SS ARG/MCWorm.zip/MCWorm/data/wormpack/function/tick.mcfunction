execute unless score #state sandworm matches 1.. run return 0
execute if score #hitcd sandworm matches 1.. run scoreboard players remove #hitcd sandworm 1
function wormpack:health/poll
execute if score #state sandworm matches 1 run return run function wormpack:idle/tick
function wormpack:act/tick
