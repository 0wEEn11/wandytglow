execute unless score #state sandworm matches 1 run return 0
execute unless entity @e[type=marker,tag=ww.anchor] run return 0
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s unless entity @p[gamemode=!spectator,distance=..80] run return 0
scoreboard players set #state sandworm 2
scoreboard players set #act sandworm 4
scoreboard players set #t sandworm 0
