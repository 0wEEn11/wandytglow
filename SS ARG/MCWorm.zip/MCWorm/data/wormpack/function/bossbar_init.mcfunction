bossbar add wormpack:health "Sandworm"
bossbar set wormpack:health color red
bossbar set wormpack:health style notched_20
execute if data storage wormpack:data bb.name run function wormpack:bossbar_apply_name with storage wormpack:data bb
scoreboard players set #bb sandworm 2
