scoreboard players add #c sandworm 1
execute if score #c sandworm matches 4.. run function wormpack:idle/update
