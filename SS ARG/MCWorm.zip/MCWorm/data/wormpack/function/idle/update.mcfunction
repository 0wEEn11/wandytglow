scoreboard players set #c sandworm 0
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s if entity @p[gamemode=!spectator,distance=..80] run function wormpack:idle/turn
