tp @s ~ ~ ~ facing entity @p[gamemode=!spectator,distance=..80] feet
execute store result score #tgt sandworm run data get entity @s Rotation[0] 1
scoreboard players operation #d sandworm = #tgt sandworm
scoreboard players operation #d sandworm -= #yaw sandworm
execute if score #d sandworm matches 181.. run scoreboard players remove #d sandworm 360
execute if score #d sandworm matches ..-181 run scoreboard players add #d sandworm 360
execute if score #d sandworm > #rate sandworm run scoreboard players operation #d sandworm = #rate sandworm
execute if score #d sandworm < #nrate sandworm run scoreboard players operation #d sandworm = #nrate sandworm
execute if score #d sandworm matches 0 run return 0
scoreboard players operation #yaw sandworm += #d sandworm
execute if score #yaw sandworm matches 181.. run scoreboard players remove #yaw sandworm 360
execute if score #yaw sandworm matches ..-181 run scoreboard players add #yaw sandworm 360
function wormpack:util/apply_yaw
function wormpack:hitbox/idle
