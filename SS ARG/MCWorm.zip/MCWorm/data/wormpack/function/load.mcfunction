scoreboard objectives add sandworm dummy
execute unless score #state sandworm matches 0.. run scoreboard players set #state sandworm 0
execute unless score #act sandworm matches 0.. run scoreboard players set #act sandworm 0
execute unless score #yaw sandworm matches -180..180 run scoreboard players set #yaw sandworm 0
execute unless score #maxhp sandworm matches 1.. run scoreboard players set #maxhp sandworm 200
execute unless score #hp sandworm matches -1000000.. run scoreboard players set #hp sandworm 200
execute unless score #dmgmult sandworm matches 1.. run scoreboard players set #dmgmult sandworm 100
execute unless score #hitcd sandworm matches 0.. run scoreboard players set #hitcd sandworm 0
scoreboard players set #k50 sandworm 50
scoreboard players set #k10000 sandworm 10000
execute unless score #dead sandworm matches 0.. run scoreboard players set #dead sandworm 0
scoreboard players set #rate sandworm 8
scoreboard players set #nrate sandworm -8
