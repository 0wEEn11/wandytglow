$bossbar set wormpack:health name "$(name)"
