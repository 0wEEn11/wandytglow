scoreboard players set #bin sandworm 13
execute if entity @p[gamemode=!spectator,distance=..12.0] run scoreboard players set #bin sandworm 11
execute if entity @p[gamemode=!spectator,distance=..10.0] run scoreboard players set #bin sandworm 9
execute if entity @p[gamemode=!spectator,distance=..8.0] run scoreboard players set #bin sandworm 7
execute if entity @p[gamemode=!spectator,distance=..6.0] run scoreboard players set #bin sandworm 5
