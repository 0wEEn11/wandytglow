particle block{block_state:"minecraft:sand"} ~ ~0.5 ~ 1.8 0.5 1.8 0.45 220 force
particle minecraft:explosion ~ ~0.3 ~ 0.6 0.1 0.6 0 4 force
playsound minecraft:entity.generic.explode hostile @a ~ ~ ~ 5 0.6
playsound minecraft:block.sand.break hostile @a ~ ~ ~ 5 0.5
