execute if score #t sandworm matches 1 run function wormpack:util/tpdur {n:10}
execute if score #t sandworm matches 1 run function wormpack:util/aim
execute if score #t sandworm matches 1 run function wormpack:pose/slide_0 {d:10}
execute if score #t sandworm matches 1 run playsound minecraft:entity.ravager.roar hostile @a ~ ~ ~ 5 0.5
execute if score #t sandworm matches 1 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 2.5 0.4 2.5 0.25 60 force
execute if score #t sandworm matches 11 run function wormpack:util/tpdur {n:4}
execute if score #t sandworm matches 11 run function wormpack:util/aim
execute if score #t sandworm matches 11 run function wormpack:act/slide_pick
execute if score #t sandworm matches 11 run execute if score #bin sandworm matches 3 run function wormpack:pose/slide_3 {d:12}
execute if score #t sandworm matches 11 run execute if score #bin sandworm matches 6 run function wormpack:pose/slide_6 {d:12}
execute if score #t sandworm matches 11 run execute if score #bin sandworm matches 9 run function wormpack:pose/slide_9 {d:12}
execute if score #t sandworm matches 11 run execute if score #bin sandworm matches 12 run function wormpack:pose/slide_12 {d:12}
execute if score #t sandworm matches 11 run playsound minecraft:entity.warden.dig hostile @a ~ ~ ~ 5 0.4
execute if score #t sandworm matches 13 run function wormpack:act/slide_trail
execute if score #t sandworm matches 16 run function wormpack:act/slide_trail
execute if score #t sandworm matches 19 run function wormpack:act/slide_trail
execute if score #t sandworm matches 22 run function wormpack:act/slide_trail
execute if score #t sandworm matches 21..29 run function wormpack:act/slide_hit
execute if score #t sandworm matches 23 run function wormpack:act/slide_fx
execute if score #t sandworm matches 6 run function wormpack:hitbox/slide_0
execute if score #t sandworm matches 17 run execute if score #bin sandworm matches 3 run function wormpack:hitbox/slide_3
execute if score #t sandworm matches 17 run execute if score #bin sandworm matches 6 run function wormpack:hitbox/slide_6
execute if score #t sandworm matches 17 run execute if score #bin sandworm matches 9 run function wormpack:hitbox/slide_9
execute if score #t sandworm matches 17 run execute if score #bin sandworm matches 12 run function wormpack:hitbox/slide_12
execute if score #t sandworm matches 46 run function wormpack:hitbox/idle
execute if score #t sandworm matches 33 run function wormpack:pose/idle {d:26}
execute if score #t sandworm matches 60 run function wormpack:act/finish
