execute if score #bin sandworm matches 5 rotated ~ 0 positioned ^ ^ ^5 run particle block{block_state:"minecraft:sand"} ~ ~0.5 ~ 1.5 0.3 1.5 0.15 40 force
execute if score #bin sandworm matches 7 rotated ~ 0 positioned ^ ^ ^7 run particle block{block_state:"minecraft:sand"} ~ ~0.5 ~ 1.5 0.3 1.5 0.15 40 force
execute if score #bin sandworm matches 9 rotated ~ 0 positioned ^ ^ ^9 run particle block{block_state:"minecraft:sand"} ~ ~0.5 ~ 1.5 0.3 1.5 0.15 40 force
execute if score #bin sandworm matches 11 rotated ~ 0 positioned ^ ^ ^11 run particle block{block_state:"minecraft:sand"} ~ ~0.5 ~ 1.5 0.3 1.5 0.15 40 force
execute if score #bin sandworm matches 13 rotated ~ 0 positioned ^ ^ ^13 run particle block{block_state:"minecraft:sand"} ~ ~0.5 ~ 1.5 0.3 1.5 0.15 40 force
