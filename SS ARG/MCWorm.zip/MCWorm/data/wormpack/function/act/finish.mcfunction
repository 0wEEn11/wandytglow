scoreboard players set #state sandworm 1
scoreboard players set #act sandworm 0
scoreboard players set #c sandworm 0
function wormpack:hitbox/idle
execute if score #dead sandworm matches 1 if score #hp sandworm matches ..0 run function wormpack:health/kill_now
scoreboard players set #dead sandworm 0
