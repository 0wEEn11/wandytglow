execute if score #t sandworm matches 1 run playsound minecraft:entity.warden.emerge hostile @a ~ ~ ~ 5 0.5
execute if score #t sandworm matches 3 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 2.5 0.4 2.5 0.25 120 force
execute if score #t sandworm matches 3 run function wormpack:pose/emerge_1 {d:4}
execute if score #t sandworm matches 7 run function wormpack:pose/emerge_2 {d:4}
execute if score #t sandworm matches 7 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 2.2 0.4 2.2 0.25 70 force
execute if score #t sandworm matches 11 run function wormpack:pose/emerge_3 {d:4}
execute if score #t sandworm matches 11 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 2.2 0.4 2.2 0.25 70 force
execute if score #t sandworm matches 15 run function wormpack:pose/emerge_4 {d:4}
execute if score #t sandworm matches 15 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 2.2 0.4 2.2 0.25 70 force
execute if score #t sandworm matches 19 run function wormpack:pose/idle {d:4}
execute if score #t sandworm matches 19 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 2.2 0.4 2.2 0.25 70 force
execute if score #t sandworm matches 23 run playsound minecraft:entity.ravager.roar hostile @a ~ ~ ~ 6 0.5
execute if score #t sandworm matches 23 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 3 0.5 3 0.25 100 force
execute if score #t sandworm matches 23 run function wormpack:act/finish
