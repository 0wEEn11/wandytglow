kill @e[type=interaction,tag=ww.hitbox]
scoreboard players set #dead sandworm 0
kill @e[type=block_display,tag=ww.part]
kill @e[type=marker,tag=ww.anchor]
scoreboard players set #state sandworm 0
scoreboard players set #act sandworm 0
