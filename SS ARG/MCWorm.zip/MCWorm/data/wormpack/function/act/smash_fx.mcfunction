execute if score #bin sandworm matches 5 rotated ~ 0 positioned ^ ^ ^5 run function wormpack:act/impact_fx
execute if score #bin sandworm matches 7 rotated ~ 0 positioned ^ ^ ^7 run function wormpack:act/impact_fx
execute if score #bin sandworm matches 9 rotated ~ 0 positioned ^ ^ ^9 run function wormpack:act/impact_fx
execute if score #bin sandworm matches 11 rotated ~ 0 positioned ^ ^ ^11 run function wormpack:act/impact_fx
execute if score #bin sandworm matches 13 rotated ~ 0 positioned ^ ^ ^13 run function wormpack:act/impact_fx
