scoreboard players add #t sandworm 1
execute if score #act sandworm matches 1 run function wormpack:act/burrow
execute if score #act sandworm matches 2 run function wormpack:act/emerge
execute if score #act sandworm matches 3 run function wormpack:act/smash
execute if score #act sandworm matches 4 run function wormpack:act/slide
