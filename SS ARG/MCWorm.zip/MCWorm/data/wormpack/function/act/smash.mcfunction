execute if score #t sandworm matches 1 run function wormpack:util/tpdur {n:10}
execute if score #t sandworm matches 1 run function wormpack:util/aim
execute if score #t sandworm matches 1 run function wormpack:pose/windup {d:10}
execute if score #t sandworm matches 1 run playsound minecraft:entity.ravager.roar hostile @a ~ ~ ~ 5 0.6
execute if score #t sandworm matches 11 run function wormpack:util/tpdur {n:4}
execute if score #t sandworm matches 11 run function wormpack:util/aim
execute if score #t sandworm matches 11 run function wormpack:act/smash_pick
execute if score #t sandworm matches 11 run execute if score #bin sandworm matches 5 run function wormpack:pose/smash_5 {d:4}
execute if score #t sandworm matches 11 run execute if score #bin sandworm matches 7 run function wormpack:pose/smash_7 {d:4}
execute if score #t sandworm matches 11 run execute if score #bin sandworm matches 9 run function wormpack:pose/smash_9 {d:4}
execute if score #t sandworm matches 11 run execute if score #bin sandworm matches 11 run function wormpack:pose/smash_11 {d:4}
execute if score #t sandworm matches 11 run execute if score #bin sandworm matches 13 run function wormpack:pose/smash_13 {d:4}
execute if score #t sandworm matches 15..16 run function wormpack:act/smash_hit
execute if score #t sandworm matches 15 run function wormpack:act/smash_fx
execute if score #t sandworm matches 20 run function wormpack:act/smash_fx_small
execute if score #t sandworm matches 6 run function wormpack:hitbox/windup
execute if score #t sandworm matches 13 run execute if score #bin sandworm matches 5 run function wormpack:hitbox/smash_5
execute if score #t sandworm matches 13 run execute if score #bin sandworm matches 7 run function wormpack:hitbox/smash_7
execute if score #t sandworm matches 13 run execute if score #bin sandworm matches 9 run function wormpack:hitbox/smash_9
execute if score #t sandworm matches 13 run execute if score #bin sandworm matches 11 run function wormpack:hitbox/smash_11
execute if score #t sandworm matches 13 run execute if score #bin sandworm matches 13 run function wormpack:hitbox/smash_13
execute if score #t sandworm matches 39 run function wormpack:hitbox/idle
execute if score #t sandworm matches 27 run function wormpack:pose/idle {d:24}
execute if score #t sandworm matches 52 run function wormpack:act/finish
