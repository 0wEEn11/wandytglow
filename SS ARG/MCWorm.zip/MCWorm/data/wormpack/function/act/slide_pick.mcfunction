scoreboard players set #bin sandworm 12
execute if entity @p[gamemode=!spectator,distance=..21.6] run scoreboard players set #bin sandworm 9
execute if entity @p[gamemode=!spectator,distance=..18.6] run scoreboard players set #bin sandworm 6
execute if entity @p[gamemode=!spectator,distance=..15.6] run scoreboard players set #bin sandworm 3
execute if entity @p[gamemode=!spectator,distance=..12.6] run scoreboard players set #bin sandworm 0
