execute if score #t sandworm matches 1 run playsound minecraft:entity.warden.dig hostile @a ~ ~ ~ 4 0.5
execute if score #t sandworm matches 1 run playsound minecraft:entity.ravager.roar hostile @a ~ ~ ~ 4 0.6
execute if score #t sandworm matches 1 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 2.5 0.4 2.5 0.25 60 force
execute if score #t sandworm matches 2 run function wormpack:pose/burrow_1 {d:4}
execute if score #t sandworm matches 6 run function wormpack:pose/burrow_2 {d:4}
execute if score #t sandworm matches 10 run function wormpack:pose/burrow_3 {d:4}
execute if score #t sandworm matches 14 run function wormpack:pose/burrow_4 {d:4}
execute if score #t sandworm matches 18 run function wormpack:pose/burrow_5 {d:4}
execute if score #t sandworm matches 22 run function wormpack:pose/burrow_6 {d:4}
execute if score #t sandworm matches 26 run function wormpack:pose/burrow_7 {d:4}
execute if score #t sandworm matches 14 run execute rotated ~ 0 positioned ^ ^ ^5.90 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 2 0.4 2 0.25 110 force
execute if score #t sandworm matches 14 run playsound minecraft:block.sand.break hostile @a ~ ~ ~ 4 0.5
execute if score #t sandworm matches 18 run execute rotated ~ 0 positioned ^ ^ ^5.90 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 2 0.4 2 0.25 60 force
execute if score #t sandworm matches 22 run execute rotated ~ 0 positioned ^ ^ ^5.90 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 2 0.4 2 0.25 60 force
execute if score #t sandworm matches 26 run execute rotated ~ 0 positioned ^ ^ ^5.90 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 2 0.4 2 0.25 60 force
execute if score #t sandworm matches 30 run execute rotated ~ 0 positioned ^ ^ ^5.90 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 2 0.4 2 0.25 60 force
execute if score #t sandworm matches 31 run particle block{block_state:"minecraft:sand"} ~ ~0.3 ~ 2.5 0.4 2.5 0.25 80 force
execute if score #t sandworm matches 31 run function wormpack:act/burrow_done
