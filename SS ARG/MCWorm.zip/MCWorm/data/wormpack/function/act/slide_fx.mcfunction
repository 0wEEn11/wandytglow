execute if score #bin sandworm matches 0 rotated ~ 0 positioned ^ ^ ^11.06 run function wormpack:act/impact_fx
execute if score #bin sandworm matches 3 rotated ~ 0 positioned ^ ^ ^14.06 run function wormpack:act/impact_fx
execute if score #bin sandworm matches 6 rotated ~ 0 positioned ^ ^ ^17.06 run function wormpack:act/impact_fx
execute if score #bin sandworm matches 9 rotated ~ 0 positioned ^ ^ ^20.06 run function wormpack:act/impact_fx
execute if score #bin sandworm matches 12 rotated ~ 0 positioned ^ ^ ^23.06 run function wormpack:act/impact_fx
