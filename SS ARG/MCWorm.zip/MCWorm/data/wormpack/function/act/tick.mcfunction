execute as @e[type=marker,tag=ww.anchor,limit=1] at @s run function wormpack:act/dispatch
