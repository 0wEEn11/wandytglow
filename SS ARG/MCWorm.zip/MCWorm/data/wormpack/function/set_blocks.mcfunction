$data modify storage wormpack:data blocks set value {body:"$(body)",teeth:"$(teeth)",throat:"$(throat)"}
function wormpack:util/apply_blocks with storage wormpack:data blocks
