execute if entity @p[gamemode=!spectator,distance=..80] run return run function wormpack:util/aim
function wormpack:util/apply_yaw
