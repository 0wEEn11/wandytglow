$execute as @e[type=block_display,tag=ww.part] run data merge entity @s {teleport_duration:$(n)}
