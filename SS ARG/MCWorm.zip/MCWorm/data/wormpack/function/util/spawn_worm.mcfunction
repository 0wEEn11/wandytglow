kill @e[type=block_display,tag=ww.part]
kill @e[type=marker,tag=ww.anchor]
kill @e[type=interaction,tag=ww.hitbox]
summon minecraft:marker ~ ~ ~ {Tags:["ww.anchor"]}
summon minecraft:interaction ~ ~300 ~ {Tags:["ww.hitbox","ww.hb0"],width:3.4f,height:3.4f,response:false}
summon minecraft:interaction ~ ~300 ~ {Tags:["ww.hitbox","ww.hb1"],width:3.4f,height:3.4f,response:false}
summon minecraft:interaction ~ ~300 ~ {Tags:["ww.hitbox","ww.hb2"],width:3.4f,height:3.4f,response:false}
summon minecraft:interaction ~ ~300 ~ {Tags:["ww.hitbox","ww.hb3"],width:3.4f,height:3.4f,response:false}
summon minecraft:interaction ~ ~300 ~ {Tags:["ww.hitbox","ww.hb4"],width:3.4f,height:3.4f,response:false}
summon minecraft:interaction ~ ~300 ~ {Tags:["ww.hitbox","ww.hb5"],width:3.4f,height:3.4f,response:false}
summon minecraft:interaction ~ ~300 ~ {Tags:["ww.hitbox","ww.hb6"],width:3.4f,height:3.4f,response:false}
summon minecraft:interaction ~ ~300 ~ {Tags:["ww.hitbox","ww.hb7"],width:4.2f,height:4.2f,response:false}
execute unless score #hp sandworm matches 1.. run scoreboard players operation #hp sandworm = #maxhp sandworm
scoreboard players set #dead sandworm 0
scoreboard players set #hitcd sandworm 0
function wormpack:util/spawn_parts
execute if data storage wormpack:data blocks run function wormpack:util/apply_blocks with storage wormpack:data blocks
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s run function wormpack:util/face_or_keep
