function wormpack:util/spawn_worm
function wormpack:pose/emerge_0 {d:0}
scoreboard players set #state sandworm 2
scoreboard players set #act sandworm 2
scoreboard players set #t sandworm 0
