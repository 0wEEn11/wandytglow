execute store result storage wormpack:data args.yaw int 1 run scoreboard players get #yaw sandworm
function wormpack:util/apply_yaw_m with storage wormpack:data args
