tp @s ~ ~ ~ facing entity @p[gamemode=!spectator,distance=..80] feet
execute store result score #yaw sandworm run data get entity @s Rotation[0] 1
function wormpack:util/apply_yaw
