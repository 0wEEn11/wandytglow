function wormpack:util/spawn_worm
function wormpack:pose/idle {d:0}
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s run function wormpack:hitbox/idle
scoreboard players set #state sandworm 1
scoreboard players set #act sandworm 0
scoreboard players set #c sandworm 0
