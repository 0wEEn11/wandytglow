$tp @e[type=block_display,tag=ww.part] ~ ~ ~ $(yaw) 0
$tp @s ~ ~ ~ $(yaw) 0
