execute unless score #state sandworm matches 0 run return 0
execute align xyz positioned ~0.5 ~ ~0.5 run function wormpack:util/emerge_core
