bossbar remove wormpack:health
scoreboard players set #bb sandworm 0
