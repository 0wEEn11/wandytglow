$data modify storage wormpack:data bb.name set value "$(name)"
execute unless score #bb sandworm matches 2 run function wormpack:bossbar_reset
function wormpack:bossbar_apply_name with storage wormpack:data bb
