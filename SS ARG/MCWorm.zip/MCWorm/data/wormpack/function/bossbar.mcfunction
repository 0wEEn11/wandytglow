execute if score #state sandworm matches 0 run return run bossbar set wormpack:health visible false
bossbar set wormpack:health visible true
execute as @e[type=marker,tag=ww.anchor,limit=1] at @s run bossbar set wormpack:health players @a[distance=..96]
scoreboard players operation #bbv sandworm = #hp sandworm
execute if score #bbv sandworm matches ..-1 run scoreboard players set #bbv sandworm 0
execute store result bossbar wormpack:health max run scoreboard players get #maxhp sandworm
execute store result bossbar wormpack:health value run scoreboard players get #bbv sandworm
